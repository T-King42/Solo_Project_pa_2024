##Welcome to my solo project for the end of my Coding Dojo journey.

hopefully this project will be a good representation of the skills that I have gained here.
For this project I have decided to build a web application for keeping track of my yu-gi-oh trading card collection.
It stores both cards and decks made up of those cards and supports will support multiple users.

users can
    -Add Cards
    -Build Decks
    -Keep track of remaining cards
    -Look at card descriptions
    -delete existing decks
    -edit existing decks
    -view decks created by other users

Time permitting, I would like to add functionality to query the public yugioh API to pull card information from their database, and add card image functionality.

